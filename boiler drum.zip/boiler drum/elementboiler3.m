clc;
clear;
close all;

%% THREE-ELEMENT BOILER DRUM LEVEL CONTROL
% MATLAB simulation
% Elements:
% 1. Drum level
% 2. Steam flow
% 3. Feedwater flow

%% Simulation parameters
dt = 0.1;
t = 0:dt:300;
N = length(t);

%% Drum parameters
Lsp = 50;                 % Drum level setpoint (%)
L0 = 50;                  % Initial level (%)

tau_drum = 18;            % Drum level time constant (s)
K_level = 0.08;           % Level response gain

% Shrink/Swell coefficient
K_ss = 0.04;

%% Steam flow
steam = 100 * ones(1,N);

% Steam demand disturbance
steam(t >= 80 & t < 160) = 125;
steam(t >= 160 & t < 230) = 90;
steam(t >= 230) = 115;

%% Feedwater flow
fw = 100 * ones(1,N);

%% PI Controller - Outer Level Loop
Kp_L = 2.2;
Ki_L = 0.12;

level_error = zeros(1,N);
level_integral = zeros(1,N);
level_controller = zeros(1,N);

%% PI Controller - Inner Feedwater Flow Loop
Kp_F = 1.8;
Ki_F = 0.25;

flow_error = zeros(1,N);
flow_integral = zeros(1,N);
valve_cmd = zeros(1,N);

%% Drum level
level = zeros(1,N);
level(1) = L0;

%% Trips
high_trip = zeros(1,N);
low_trip = zeros(1,N);

high_limit = 65;
low_limit = 35;

high_latched = false;
low_latched = false;

%% Feedforward gain
Kff = 1.0;

%% Simulation
for k = 2:N

    % 1. Outer drum-level control loop
    level_error(k) = Lsp - level(k-1);

    level_integral(k) = level_integral(k-1) + ...
                        level_error(k)*dt;

    level_controller(k) = Kp_L*level_error(k) + ...
                          Ki_L*level_integral(k);

    % 2. Steam-flow feedforward
  
    feedforward = Kff * (steam(k) - 100);

    % Required feedwater-flow setpoint
    fw_sp = 100 + level_controller(k) + feedforward;

    %% Limit feedwater demand
    fw_sp = max(70,min(140,fw_sp));

    % 3. Inner feedwater-flow PI loop
    flow_error(k) = fw_sp - fw(k-1);

    flow_integral(k) = flow_integral(k-1) + ...
                       flow_error(k)*dt;

    valve_cmd(k) = Kp_F*flow_error(k) + ...
                   Ki_F*flow_integral(k);

    %% Feedwater dynamics
    fw(k) = fw(k-1) + dt/tau_drum * ...
           (valve_cmd(k) - fw(k-1) + 100);

    %% Limit feedwater flow
    fw(k) = max(50,min(150,fw(k)));

    % 4. Shrink/Swell effect
    flow_imbalance = fw(k) - steam(k);

    % Basic mass-balance level response
    mass_effect = K_level * flow_imbalance;

    % Shrink/swell due to steam-flow variation
    steam_change = steam(k) - steam(k-1);

    shrink_swell = -K_ss * steam_change;

    %% Drum level dynamics
    dL = (-level(k-1) + Lsp)/tau_drum ...
         + mass_effect ...
         + shrink_swell;

    level(k) = level(k-1) + dt*dL;

    % 5. High/Low level trip logic
   
    if level(k) >= high_limit
        high_latched = true;
    end

    if level(k) <= low_limit
        low_latched = true;
    end

    high_trip(k) = high_latched;
    low_trip(k) = low_latched;

    %% Trip action
    if high_latched
        fw(k) = 70;
    end

    if low_latched
        fw(k) = 140;
    end

end
% SINGLE-ELEMENT CONTROL FOR COMPARISON

level_single = zeros(1,N);
level_single(1) = L0;

Kp_single = 1.5;
Ki_single = 0.08;

integral_single = 0;

for k = 2:N

    error_single = Lsp - level_single(k-1);

    integral_single = integral_single + ...
                      error_single*dt;

    fw_single = 100 + ...
                Kp_single*error_single + ...
                Ki_single*integral_single;

    fw_single = max(60,min(140,fw_single));

    flow_imbalance = fw_single - steam(k);

    shrink_swell = -K_ss * ...
                   (steam(k)-steam(k-1));

    dL = (-level_single(k-1)+Lsp)/tau_drum ...
         + K_level*flow_imbalance ...
         + shrink_swell;

    level_single(k) = level_single(k-1) + dt*dL;

end

deviation_three = max(abs(level-Lsp));
deviation_single = max(abs(level_single-Lsp));

reduction = (deviation_single-deviation_three) / ...
            deviation_single * 100;

fprintf('\n============================================\n');
fprintf(' THREE-ELEMENT BOILER DRUM CONTROL\n');
fprintf('============================================\n');

fprintf('Peak deviation - Three Element : %.2f %%\n', ...
        deviation_three);

fprintf('Peak deviation - Single Element: %.2f %%\n', ...
        deviation_single);

fprintf('Deviation reduction            : %.2f %%\n', ...
        reduction);
% PLOT 1 - DRUM LEVEL COMPARISON

figure;

plot(t,level,'LineWidth',2);
hold on;
plot(t,level_single,'--','LineWidth',2);
yline(Lsp,':','LineWidth',1.5);

yline(high_limit,'-.','High Trip');
yline(low_limit,'-.','Low Trip');

grid on;
box on;

xlabel('Time (s)');
ylabel('Drum Level (%)');

title('Boiler Drum Level Control');

legend('Three-Element Control', ...
       'Single-Element Control', ...
       'Level Setpoint', ...
       'High Trip', ...
       'Low Trip', ...
       'Location','best');
% PLOT 2 - STEAM AND FEEDWATER FLOW

figure;

plot(t,steam,'LineWidth',2);
hold on;
plot(t,fw,'LineWidth',2);

grid on;
box on;

xlabel('Time (s)');
ylabel('Flow (%)');

title('Steam Flow and Feedwater Flow');

legend('Steam Flow','Feedwater Flow', ...
       'Location','best');
% PLOT 3 - CONTROL SIGNAL

figure;

plot(t,level_controller,'LineWidth',2);
hold on;
plot(t,valve_cmd,'--','LineWidth',2);

grid on;
box on;

xlabel('Time (s)');
ylabel('Controller Output');

title('Cascade PI Controller Response');

legend('Level PI Output', ...
       'Feedwater Flow PI Output', ...
       'Location','best');
% PLOT 4 - TRIP STATUS

figure;

stairs(t,high_trip,'LineWidth',2);
hold on;
stairs(t,low_trip,'--','LineWidth',2);

grid on;
box on;

xlabel('Time (s)');
ylabel('Trip Status');

title('Latched Boiler Drum Level Trips');

legend('High-Level Trip','Low-Level Trip');

ylim([-0.1 1.1]);

fprintf('\nSimulation completed successfully.\n');